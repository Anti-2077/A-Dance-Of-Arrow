# Rhythm Forge — 분리된 파일 구조

이 폴더는 기존 사이트를 화면/스타일/기능 파일로 나눈 버전입니다. 기존 화면 ID와 JavaScript 코드를 유지해 기능 충돌을 최소화했습니다.

## 폴더 구조
- `index.html`: 사이트 시작점과 화면/스크립트 로더
- `screens/home-login.html`: 로그인/게스트 시작 화면
- `screens/main-menu.html`: 로그인 이후 메인 메뉴
- `screens/gameplay.html`: 일반 게임 플레이 전용 화면
- `screens/editor.html`: 채보 에디터 전용 화면
- `screens/settings.html`: 설정 화면
- `screens/auto-chart.html`: 자동 채보 생성 화면
- `screens/community.html`: 공개 채보 화면
- `css/styles.css`: 기존 CSS 전체(원래 선언 순서 유지)
- `js/`: 기존 JavaScript를 실행 순서대로 분리한 파일

## GitHub Pages 업로드 방법
1. ZIP 압축을 풉니다.
2. 저장소의 기존 파일을 백업합니다.
3. 이 폴더 안의 `index.html`, `css`, `js`, `screens`를 저장소 최상위에 업로드합니다. `index.html`이 저장소 최상위에 있어야 합니다.
4. GitHub Pages 사이트 주소로 접속해 확인합니다. 화면 조각을 `fetch()`로 불러오므로 파일을 더블클릭해 `file://`로 실행하지 말고 GitHub Pages 또는 로컬 웹서버에서 테스트하세요.

## 주의
- 기존 Firebase 설정은 원본과 동일하게 유지됩니다. 공개 채보/클라우드 기능을 쓰려면 Firebase 설정값이 필요합니다.
- 이 분리는 구조를 나눈 것이며, 게임 기능 자체를 새로 작성한 것은 아닙니다. 업로드 후 각 화면과 편집/플레이 기능을 확인해 주세요.
